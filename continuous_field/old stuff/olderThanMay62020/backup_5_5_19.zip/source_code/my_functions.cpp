#include "my_functions.h"

#include <iostream>
#include <fstream>
#include "threevector.h"
#include "threematrix.h"
#include "magnet.h"
#include "screen.h"



void outfile_tab(double& time, std::ofstream& out_time, ThreeVec pos, std::ofstream& out_xpos, std::ofstream& out_ypos, std::ofstream& out_zpos, ThreeVec vel, std::ofstream& out_vx, std::ofstream& out_vy, std::ofstream& out_vz)
{
    out_time << time << "\t";
    out_xpos << pos.get(0) << "\t";
    out_ypos << pos.get(1) << "\t";
    out_zpos << pos.get(2) << "\t";
    out_vx << vel.get(0) << "\t";
    out_vy << vel.get(1) << "\t";
    out_vz << vel.get(2) << "\t";
}

void outfile_part_writeAndTab(Particle& particle)
{
    *(particle.m_out_time) << (particle.get_time()) << "\t";
    *(particle.m_out_posx) << (particle.get_pos(0)) << "\t";
    *(particle.m_out_posy) << (particle.get_pos(1)) << "\t";
    *(particle.m_out_posz) << (particle.get_pos(2)) << "\t";
    *(particle.m_out_velx) << (particle.get_vel(0)) << "\t";
    *(particle.m_out_vely) << (particle.get_vel(1)) << "\t";
    *(particle.m_out_velz) << (particle.get_vel(2)) << "\t";
}


void outfile_part_writeAndComma(Particle& particle)
{
    *(particle.m_out_time) << (particle.get_time()) << ",";
    *(particle.m_out_posx) << (particle.get_pos(0)) << ",";
    *(particle.m_out_posy) << (particle.get_pos(1)) << ",";
    *(particle.m_out_posz) << (particle.get_pos(2)) << ",";
    *(particle.m_out_velx) << (particle.get_vel(0)) << ",";
    *(particle.m_out_vely) << (particle.get_vel(1)) << ",";
    *(particle.m_out_velz) << (particle.get_vel(2)) << ",";
}

void outfile_part_write(Particle& particle)
{
    *(particle.m_out_time) << (particle.get_time());
    *(particle.m_out_posx) << (particle.get_pos(0));
    *(particle.m_out_posy) << (particle.get_pos(1));
    *(particle.m_out_posz) << (particle.get_pos(2));
    *(particle.m_out_velx) << (particle.get_vel(0));
    *(particle.m_out_vely) << (particle.get_vel(1));
    *(particle.m_out_velz) << (particle.get_vel(2));
}

void outfile_newline(std::ofstream& out_time, std::ofstream& out_xpos, std::ofstream& out_ypos, std::ofstream& out_zpos, std::ofstream& out_vx, std::ofstream& out_vy, std::ofstream& out_vz)
{
    out_time << "\n";
    out_xpos << "\n";
    out_ypos << "\n";
    out_zpos << "\n";
    out_vx << "\n";
    out_vy << "\n";
    out_vz << "\n";
    //std::cerr << test << '\n';
}

void outfile_part_newline(Particle& particle)
{
    *(particle.m_out_time) << "\n";
    *(particle.m_out_posx) << "\n";
    *(particle.m_out_posy) << "\n";
    *(particle.m_out_posz) << "\n";
    *(particle.m_out_velx) << "\n";
    *(particle.m_out_vely) << "\n";
    *(particle.m_out_velz) << "\n";
    //std::cerr << test << '\n';
    //test++;
}

void outfile_part_comma(Particle& particle)
{
    *(particle.m_out_time) << ",";
    *(particle.m_out_posx) << ",";
    *(particle.m_out_posy) << ",";
    *(particle.m_out_posz) << ",";
    *(particle.m_out_velx) << ",";
    *(particle.m_out_vely) << ",";
    *(particle.m_out_velz) << ",";
}

void outfile_uniform_magnet(Magnet& magnet, int counter)
{
    if(counter==0)
    {
        *(magnet.m_out_magnet) << "Num ," << "Bz(norm) ," << "mag_posx ," << "mag_posy ," << "mag_posz ," << "length ," << "width" << "\n";
    }
    *(magnet.m_out_magnet) << (counter+1) << "," << magnet.get_B0(2) << "," 
                            << magnet.get_pos(0) << "," << magnet.get_pos(1) << "," << magnet.get_pos(2) << ","
                            << magnet.get_length() << "," << magnet.get_width() << '\n';
} 

// Gaussian random distribution function
double gaussian()
{
	double gaussian_width=1.0; // +/- 1 sigma range
	double x, y;
	do
	{
		x = (2.0*rand()/RAND_MAX-1.0)*gaussian_width;
		y = exp(-x*x*0.5);
	}
	while (1.0*rand()/RAND_MAX > y);
	return x;
}

double uniform_dist_single(int num_par_t, double vel0_t, double radius_v0_t, int &counter_t)
{
    double del_vel = (vel0_t+radius_v0_t - (vel0_t-radius_v0_t))/static_cast<double>(num_par_t);

    double counter_d = static_cast<double>(counter_t);
    counter_t++;
    return (vel0_t-radius_v0_t + (del_vel * counter_d));
}


void step_through_magnet(Particle &electron, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec B0, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double& del_time, double& width_bmap, double& length_bmap)
{
    bool check;
    do
        {
            vn_plus = vn_minus + ((electron.get_vel())^B0)*2*del_time;    //leapfrog algarithm vn for uniform B0
            rn_plus = rn_minus + (electron.get_vel())*2*del_time;         //leapfrog algarithm rn for uniform B0

            rn_minus = electron.get_pos();                          //iterate xn_minus up a timestep
            electron.set_pos(rn_plus);                              //do the same to xn

            vn_minus = (electron.get_vel());                        //iterate vn_minus up a timestep
            electron.set_vel(vn_plus);                              //do the same to vn

            time += del_time;
            
            check = (electron.get_pos(0) >= 0.0) && (electron.get_pos(0) <= length_bmap) && (electron.get_pos(1) >= (-width_bmap/2.0)) && (electron.get_pos(1) <= (width_bmap/2.0));
            if(check)
                { outfile_part_writeAndComma(electron); }
            else if(!(check))
                { outfile_part_write(electron); }            
            
        } while(check);
}

void step_through_magnet_mag(Particle &electron, Magnet &magnet, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double &del_time)
{
    bool check;
    //std::cerr << "Durring: " << electron.get_pos() << '\n';
    do
        {
            vn_plus = vn_minus + ((electron.get_vel())^(magnet.get_B0()))*2*del_time;    //leapfrog algarithm vn for uniform B0
            rn_plus = rn_minus + (electron.get_vel())*2*del_time;         //leapfrog algarithm rn for uniform B0

            //std::cerr << "electron charge: " << electron.get_charge() << '\n';
            //std::cerr << "magnet strength: " << magnet.get_B0() << "\n";

            rn_minus = electron.get_pos();                          //iterate xn_minus up a timestep
            electron.set_pos(rn_plus);                              //do the same to xn
            //std::cerr << "pos: " << electron.get_pos(0) << '\n';

            vn_minus = (electron.get_vel());                        //iterate vn_minus up a timestep
            electron.set_vel(vn_plus);                              //do the same to vn

            //std::cerr << "vel: " << electron.get_vel() << "\n";
            time += del_time;

            electron.set_time(time);

            
            check = ((electron.get_pos(0) >= (magnet.get_pos(0))) && (electron.get_pos(0) <= (magnet.get_length()+(magnet.get_pos(0)))) && (electron.get_pos(1) >= ((magnet.get_pos(1))-((magnet.get_width())/2.0))) && (electron.get_pos(1) <= ((magnet.get_pos(1))+(magnet.get_width())/2.0)));
            
            if(check)
                { outfile_part_writeAndComma(electron); }
            else if(!(check))
                { outfile_part_write(electron); }            
            
        } while(check);
        //std::cerr << electron.get_pos() << '\n' << '~' << '\n';
}

void step_through_magnet_mag(Particle *electron, Magnet &magnet, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double &del_time)
{
    bool check;
    //std::cerr << "Durring: " << electron->get_pos() << '\n' << '~' << '\n';
    do
        {
            //std::cerr << "vel: " << electron->get_vel() << "\n";
            vn_plus = vn_minus + ((electron->get_vel())^(magnet.get_B0()))*2*del_time;    //leapfrog algarithm vn for uniform B0
            rn_plus = rn_minus + (electron->get_vel())*2*del_time;         //leapfrog algarithm rn for uniform B0

            rn_minus = electron->get_pos();                          //iterate xn_minus up a timestep
            electron->set_pos(rn_plus);                              //do the same to xn

            vn_minus = (electron->get_vel());                        //iterate vn_minus up a timestep
            electron->set_vel(vn_plus);                              //do the same to vn

            //std::cerr << "vel: " << electron->get_vel() << "\n";
            time += del_time;

            
            check = ((electron->get_pos(0) >= (magnet.get_pos(0))) && (electron->get_pos(0) <= (magnet.get_length()+(magnet.get_pos(0)))) && (electron->get_pos(1) >= ((magnet.get_pos(1))-((magnet.get_width())/2.0))) && (electron->get_pos(1) <= ((magnet.get_pos(1))+(magnet.get_width())/2.0)));
            
            if(check)
                { outfile_part_writeAndComma(*electron); }
            else if(!(check))
                { outfile_part_write(*electron); }            
            
        } while(check);
        //std::cerr << electron->get_pos() << '\n' << '~' << '\n';
}