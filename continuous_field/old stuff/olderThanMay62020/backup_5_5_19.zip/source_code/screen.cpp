#include "screen.h"

#include "threevector.h"

Screen::Screen(/* args */)
{
}