#include "particle.h"

#include "threevector.h"
#include "threematrix.h"


Particle::Particle(ThreeVec pos, ThreeVec vel, int charge, double& time, std::ofstream& OUT_time, 
            std::ofstream& OUT_posx, std::ofstream& OUT_posy, std::ofstream& OUT_posz,
            std::ofstream& OUT_velx, std::ofstream& OUT_vely, std::ofstream& OUT_velz)
                : m_time(&time), m_out_time(&OUT_time), m_out_posx(&OUT_posx), m_out_posy(&OUT_posy), m_out_posz(&OUT_posz),
                    m_out_velx(&OUT_velx), m_out_vely(&OUT_vely), m_out_velz(&OUT_velz)
    {
        set_pos(pos);
        set_vel(vel);
        m_charge = charge;
    }

void Particle::set_pos(ThreeVec pos)
{
    m_pos = pos;
}

void Particle::set_pos(int index, double value)
{
    m_pos.set(index, value);
}

void Particle::set_vel(ThreeVec vel)
{
    m_vel = vel;
} 

void Particle::set_time(double& time)
{
    m_time = &time;
}