#ifndef MY_FUNCTIONS_H
#define MY_FUNCTIONS_H

#include <fstream>
#include "threevector.h"
#include "threematrix.h"
#include "particle.h"
#include "magnet.h"
#include "screen.h"

void outfile_tab(double& time, std::ofstream& out_time, ThreeVec pos, std::ofstream& out_xpos, std::ofstream& out_ypos, std::ofstream& out_zpos, ThreeVec vel, std::ofstream& out_vx, std::ofstream& out_vy, std::ofstream& out_vz);

void outfile_part_writeAndTab(Particle& particle);

void outfile_part_writeAndComma(Particle& particle);

void outfile_part_write(Particle& particle);

void outfile_newline(std::ofstream& out_time, std::ofstream& out_xpos, std::ofstream& out_ypos, std::ofstream& out_zpos, std::ofstream& out_vx, std::ofstream& out_vy, std::ofstream& out_vz);

void outfile_part_newline(Particle& particle);

void outfile_part_comma(Particle& particle);

void outfile_uniform_magnet(Magnet& magnet, int counter);

// Gaussian random distribution function
double gaussian();

double uniform_dist_single(const int num_par_t, double vel0_t, double radius_v0_t, int &counter_t);

void step_through_magnet(Particle &electron, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec B0, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double& del_time, double& width_bmap, double& length_bmap);

void step_through_magnet_mag(Particle &electron, Magnet &magnet, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double& del_time);

void step_through_magnet_mag(Particle *electron, Magnet &magnet, ThreeVec vn_plus, ThreeVec vn_minus, ThreeVec rn_plus, ThreeVec rn_minus, double& time, const double& del_time);
#endif