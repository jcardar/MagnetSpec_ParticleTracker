#ifndef SCREEN_H
#define SCREEN_H

#include "threevector.h"

class Screen
{
private:
    ThreeVec m_position;
    double m_angle;
public:
    Screen(/* args */);
    
};


#endif