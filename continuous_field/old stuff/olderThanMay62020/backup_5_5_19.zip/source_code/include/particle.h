#ifndef PARTICLE_H
#define PARTICLE_H

#include "threematrix.h"
#include "threevector.h"
#include <fstream>

class Particle
{
    ThreeVec m_pos;
    ThreeVec m_vel;
    int m_charge;
    double *m_time;

public:
    Particle() {};

    Particle(ThreeVec pos, ThreeVec vel, int charge, double& time, std::ofstream& out_time, 
            std::ofstream& out_posx, std::ofstream& out_posy, std::ofstream& out_posz,
            std::ofstream& out_velx, std::ofstream& out_vely, std::ofstream& out_velz);

    ThreeVec get_pos()
    {
        return m_pos;
    }

    double get_pos(int i)
    {
        return m_pos.get(i);
    }

    ThreeVec get_vel()
    {
        return m_vel;
    }
    double get_vel(int i)
    {
        return m_vel.get(i);
    }

    int get_charge()
    {
        return m_charge;
    }

    double get_time()
    {
        return *m_time;
    }

    void set_pos(ThreeVec pos);
    void set_pos(int index, double value);
    void set_vel(ThreeVec vel);
    void set_time(double& time);

    std::ofstream *m_out_time;
    std::ofstream *m_out_posx;
    std::ofstream *m_out_posy;
    std::ofstream *m_out_posz;
    std::ofstream *m_out_velx;
    std::ofstream *m_out_vely;
    std::ofstream *m_out_velz; 

};

#endif // !PARTICLE_H
