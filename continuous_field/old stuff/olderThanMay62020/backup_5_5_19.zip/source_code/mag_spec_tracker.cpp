/*Leap Frog Numerical Method Code
 *for tracking a particle in static B and possible E field
 *Author: Jason Cardarelli
 *NERS 574: Computational Plasma Physics
 *Prof. Alexander Thomas
 */

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <vector>
#include "my_functions.h"
#include "threevector.h"
#include "threematrix.h"
#include "particle.h"
#include "screen.h"
#include "magnet.h"


//int test = 1;

double M_c = 299792458;                         //SPEED OF LIGHT


int main(int argc, char *argv[])
{
    const int num_par{5};
    double time {0.0};                          //Define a variable time in which will be stepped over
    double del_time = 0.001;                     //Define a time step

    const int num_magnets{2};
    Magnet magnet[num_magnets];
    double length_bmap[num_magnets] = {0.2, 0.2};
    double width_bmap[num_magnets] = {0.2, 0.2};
    ThreeVec mag_B0[num_magnets];
        for(int ii{0}; ii<num_magnets; ii++)
        {
            switch(ii)
            {
            case 0:
                mag_B0[ii].setX(0.0); mag_B0[ii].setY(0.0); mag_B0[ii].setZ(1.0);
                //std::cerr << test << "\t";
                break;
            
            case 1:
                mag_B0[ii].setX(0.0); mag_B0[ii].setY(0.0); mag_B0[ii].setZ(2.0);
                //std::cerr << test << "\t";
                break;
            }
            //std::cerr << test << "\t";
        }

    ThreeVec mag_pos[num_magnets];
        for(int ii{0}; ii<num_magnets; ii++)
        {
            switch(ii)
            {
            case 0:
                mag_pos[ii].setX(0.0); mag_pos[ii].setY(0.0); mag_pos[ii].setZ(0.0);
                //std::cerr << test << "\t";
                break;
            
            case 1:
                mag_pos[ii].setX(0.25); mag_pos[ii].setY(0.0); mag_pos[ii].setZ(0.0);
                //std::cerr << test << "\t";
                break;
            }
            //std::cerr << test << "\t";
        }

    std::ofstream outfile_magnets("../data/MAGNETS.csv");

    for(int ii{0}; ii < num_magnets; ii++)
    {
        magnet[ii].set_length(length_bmap[ii]);
        magnet[ii].set_width(width_bmap[ii]);
        magnet[ii].set_B0(mag_B0[ii]);
        magnet[ii].set_pos(mag_pos[ii]);
        magnet[ii].set_outfile(outfile_magnets);
        outfile_uniform_magnet(magnet[ii], ii);
        //std::cerr << magnet[ii].get_pos(0) << '\n';
    }
    // std::cerr << magnet[0].get_pos(0) << '\n';
    // std::cerr << magnet[1].get_pos(0) << '\n';  
    
    /*
    const int n_grid_length {16};
    const int n_grid_width{16};
    double d_length[num_magnets]; 
    for(int ii{0}; ii < num_magnets; ii++)
        { 
            d_length[ii] = length_bmap[ii]/static_cast<double>(n_grid_length); 
        }
    double d_width[num_magnets];
    for(int ii{0}; ii < num_magnets; ii++)
        { 
            d_width[ii] = width_bmap[ii]/static_cast<double>(n_grid_length); 
        }
    */
    const double length_before{0.0};
    
    // std::ifstream bmap( "bmap_in.txt" );   
    std::ofstream outfile_readme("../data/README.txt");
	//std::ofstream outfile_grid("../data/GRID.txt");
	std::ofstream outfile_time("../data/TIME.csv");
	std::ofstream outfile_xpos("../data/XPOS.csv");
    std::ofstream outfile_ypos("../data/YPOS.csv");
    std::ofstream outfile_zpos("../data/ZPOS.csv");
	std::ofstream outfile_px("../data/MOMENTUM_x.csv");
	std::ofstream outfile_py("../data/MOMENTUM_y.csv");
    std::ofstream outfile_pz("../data/MOMENTUM_z.csv");
	// std::ofstream outfile_Bz("./data/Bz.txt");
	std::ofstream outfile_dump;
    std::ifstream infile;

    /*
    //                                      //BMAP ARRAY FOR WEIGHTED PARTICLE STEPPING
    double bmap[n_grid_length][n_grid_width] = {};

    enum BFieldTypes                        //ENUM TYPES DEFINING HOW WE SET MAGNETIC FIELD
    {
        BFIELD_UNIFORM,
        BFIELD_MANUAL,
    };

    BFieldTypes bfield_type {BFIELD_UNIFORM};
    switch(bfield_type)
    { 
        case BFIELD_UNIFORM:
                
            for(int col{0}; col < n_grid_length; col++)
            {                                               //ASSUMING THAT COLS -> X DIRECTION 
                for(int row{0}; row < n_grid_width; row++)
                {
                    bmap[row][col] = 1.0;
                }
            }
            break;

        case BFIELD_MANUAL:
            for(int row{0}; row<width_bmap; row++)
            {
                for(int col{0}; col<length_bmap; col++)
                {
                    std::string b_string;
                    std::string::size_type b_string_size;
                    double b_value;
                    //bmap_in >> b_string;
                    b_value = stod (b_string);
                    bmap[row][col] = b_value;
                }
            }
            break;
    }
    */



    ThreeVec B0(0.0,0.0,1.0);
    ThreeVec v0(1.0,0.0,0.0);                   //INITIAL CENTRAL VELOCITY OF UNIFORM BEAM
    ThreeVec radius_v0(0.9,0.0,0.0);           //RADIUS OF INT VELOCITIES IN PHASE SPACE
    
    ThreeVec r0(0.0,0.0,0.0);                   //INITIAL CENTRAL POSTIION OF // //
    ThreeVec radius_r0(0.0,0.0,0.0);            //RADIUS OF INT POSITIIONS IN PHASE SPACE
    int qe = -1;                                //CHARGE OF PARTICLE SPECIES (normalizd to charge of proton)

    Particle electron(r0, v0, qe, time, outfile_time, outfile_xpos, outfile_ypos, outfile_zpos, outfile_px, outfile_py, outfile_pz);

    
    double initial_x;
    double initial_y;
    double initial_z;
    double initial_vx;
    double initial_vy;
    double initial_vz;

    enum InitializationTypes
    {
        INITIALIZE_GAUSSIAN,
        INITIALIZE_UNIFORM,
    };
    InitializationTypes initialize = INITIALIZE_UNIFORM;
    int posx_counter = 0;
    int posy_counter = 0;
    int posz_counter = 0;
    int velx_counter = 0;
    int vely_counter = 0;
    int velz_counter = 0;



    for(int ii{0}; ii < num_par; ii++)
    {
        int magnet_counter = 0;
        time = 0.0;
        
        switch (initialize)
        {
        case INITIALIZE_GAUSSIAN:
            initial_x = 0.0;
            initial_y = gaussian()*(radius_r0.getY() ) + (r0.getY() );
            initial_z = gaussian()*(radius_r0.getZ() ) + (r0.getZ() );
            initial_vx = gaussian()*(radius_v0.getX() ) +(v0.getX() );
            initial_vy = gaussian()*(radius_v0.getY() ) +(v0.getY() );
            initial_vz = gaussian()*(radius_v0.getZ() ) +(v0.getZ() );
            break;
        
        case INITIALIZE_UNIFORM:
            initial_x = 0.0;
            initial_y = uniform_dist_single(num_par, r0.getY(), radius_r0.getY(), posy_counter);
            initial_z = uniform_dist_single(num_par, r0.getZ(), radius_r0.getZ(), posz_counter);
            initial_vx = uniform_dist_single(num_par, v0.getX(), radius_v0.getX(), velx_counter);
            initial_vy = uniform_dist_single(num_par, v0.getY(), radius_v0.getY(), vely_counter);
            initial_vz = uniform_dist_single(num_par, v0.getZ(), radius_v0.getZ(), velz_counter);
            break;
        }
        
        ThreeVec r_int(initial_x,initial_y, initial_z);
        ThreeVec v_int(initial_vx,initial_vy,initial_vz);
        electron.set_pos(r_int);
        electron.set_vel(v_int);
        electron.set_time(time);

        outfile_part_writeAndComma(electron);
                            /*
                            *    Determine the vn and xn at time step time = 0-del_time using 
                            *    backward difference method method: x^n = x^n+1 - del_time*(y^n+1)
                            *    where y is vxB and x is v.
                            */

        ThreeVec vn_minus = (electron.get_vel() ) - (((electron.get_vel())^B0)*del_time);
        ThreeVec vn_plus;

        ThreeVec rn_minus = (electron.get_pos() ) - ((electron.get_vel())*del_time);
        ThreeVec rn_plus;

        //step_through_magnet(electron, vn_plus, vn_minus, B0, rn_plus, rn_minus, time, del_time, width_bmap[magnet_counter], length_bmap[magnet_counter]);
        step_through_magnet_mag(electron, magnet[magnet_counter], vn_plus, vn_minus, rn_plus, rn_minus, time, del_time);
        
        while(++magnet_counter < num_magnets)
        {   //Loop through magnets after first magnet
            //magnet_counter++;
            //std::cerr << magnet_counter << '\t';
            //std::cerr << num_magnets << '\n';
            //std::cerr << electron.get_pos() << '\n';

            double dist_x_to_mag = magnet[(magnet_counter)].get_pos(0) - magnet[magnet_counter-1].get_pos(0);

            if( ( (dist_x_to_mag > 0) && ((electron.get_vel(0)) > 0) ) || ( (dist_x_to_mag < 0) && ((electron.get_vel(0)) < 0) ) )
            { //First check that electron is moving toward next magnet
                double time_btwn_mags = 0.0;
                time_btwn_mags = (((magnet[magnet_counter].get_pos(0))) - (electron.get_pos(0)))/(electron.get_vel(0)); 
                //std::cerr << magnet[magnet_counter].get_pos() <<'\n';
                //std::cerr << magnet_counter << '\n';
                //std::cerr << magnet[magnet_counter].get_pos(0) << '\n';
                //std::cerr << magnet[1].get_pos(0) << '\n'; 
                double y_at_time{0.0};
                y_at_time = (electron.get_pos(1)) + ((electron.get_vel(1))*(time_btwn_mags));
                //std::cerr << "last elec y-pos: " << electron.get_pos(1) << '\n';
                //std::cerr << "y_at_time: " << y_at_time << '\n';
                double z_at_time{0.0};
                z_at_time = (electron.get_pos(2)) + ((electron.get_vel(2))*(time_btwn_mags));
                time = time + time_btwn_mags;

                if( ((y_at_time >= (magnet[magnet_counter].get_pos(1) - (magnet[magnet_counter].get_width()/2.0) ) ) && (y_at_time <= (magnet[magnet_counter].get_pos(1) + (magnet[magnet_counter].get_width()/2.0) ))))
                {   //Then check that particle ends up in magnet region
                    //std::cerr <<"Condtion Met! \n";
                    //std::cerr <<"Mag Width = " << magnet[magnet_counter].get_width() <<'\n';
                    //std::cerr << "Mag Strength = " << magnet[magnet_counter].get_B0() << '\n';

                    //vn_minus = (electron.get_vel() ) - (((electron.get_vel())^B0)*del_time);
                    vn_minus = electron.get_vel();
                    //std::cerr << "vminus start: " << vn_minus.getX() <<'\n'<< '~' << '\n';
                    //std::cerr << "Start: " << electron.get_pos() << '\n'<< '~' << '\n';
                    electron.set_pos(0 ,(magnet[magnet_counter].get_pos(0))); 
                    //std::cerr << electron.get_pos() << '\n';
                    electron.set_pos(1, y_at_time);
                    //std::cerr << "Before: " << electron.get_pos() << '\n' << '~' << '\n';
                    rn_minus = (electron.get_pos() ) - ((electron.get_vel())*del_time);
                    //rn_minus = electron.get_pos();
                    
                    outfile_part_comma(electron);
                    step_through_magnet_mag(electron, magnet[magnet_counter], vn_plus, vn_minus, rn_plus, rn_minus, time, del_time);
                    //std::cerr << "After: " << electron.get_pos() << '\n' << '~' << '\n';
                    
                }
            }
        }   //<- end of magnetic while loop

        outfile_part_newline(electron);
    }   //<- end of particle for loop


    outfile_readme.close();
    //outfile_grid.close();
    outfile_time.close();
    outfile_xpos.close();
    outfile_ypos.close();
    outfile_zpos.close();
    outfile_px.close();
    outfile_py.close();
    outfile_pz.close();
    outfile_magnets.close();
    //infile.close();

    return 0;
}
