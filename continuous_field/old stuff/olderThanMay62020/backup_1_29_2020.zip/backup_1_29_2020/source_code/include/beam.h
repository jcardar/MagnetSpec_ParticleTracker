#ifndef BEAM_H
#define BEAM_H

#include "threematrix.h"
#include "threevector.h"
#include <fstream>
#include "particle.h"




#endif